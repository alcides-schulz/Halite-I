using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Diagnostics;
using System.Threading;

//
// Zluhcs Engine for Halite AI Programming - version 4
//
public class ZEngine
{
    public const string BOT_NAME = "zluhcs";

    private ushort      mBotID;
    private Map         mMap;

	private Direction[] CARDINALS = {Direction.North, Direction.East, Direction.South, Direction.West};
    
    private bool[,]     mMoved;

    public void Run() {
        Console.SetIn(Console.In);
        Console.SetOut(Console.Out);
		
        mMap = Networking.getInit(out mBotID);
        
        mMoved = new bool[mMap.Width, mMap.Height];
        
        Networking.SendInit(BOT_NAME);
		
        int round = 0;
        
		while (true) {
            string line = Console.ReadLine();
            if (line == null) break;

			mMap.Update(line);
            
            round++;

            var moves = new List<Move>();

            ExecuteNearBorderMove(round, moves);
            
            for (ushort y = 0; y < mMap.Height; y++) {
                for (ushort x = 0; x < mMap.Width; x++) {
                    if (mMap[x, y].Owner == mBotID && !mMoved[x, y]) {
                        moves.Add(GetMove(x, y));
                    }
                }
            }

            Networking.SendMoves(moves);
        }
    }
    
    // private void CalculateBorderMoves(int round, List<Move> moves) {
        // List<Site> my_site = new List<Site>();
        
        // for (ushort y = 0; y < mMap.Height; y++) {
            // for (ushort x = 0; x < mMap.Width; x++) {
                // Site s = mMap[x, y];
                // if (s.Owner != mBotID) continue;
                // if (!IsBorder(x, y)) continue;
                // my_site.Add(s);
            // }
        // }
        
        
    // }
    
    // Calculate moves near border, exclude combat moves.
    public void ExecuteNearBorderMove(int round, List<Move> moves) {
        if (round <= 100) {
            for (ushort y = 0; y < mMap.Height; y++) {
                for (ushort x = 0; x < mMap.Width; x++) {
                    mMoved[x, y] = false;
                }
            }
        }
        
        if (round >= 100) return;
        
        for (ushort y = 0; y < mMap.Height; y++) {
            for (ushort x = 0; x < mMap.Width; x++) {
                
                if (mMoved[x, y]) continue;
                
                var my_site = mMap[x, y];
                
                if (my_site.Owner != mBotID) continue;
                if (my_site.Strength < my_site.Production * 5) continue;
                
                bool combat_move = false;
                Direction weak_border_direction = Direction.Still;
                int weak_border_value = 1000;
                
                foreach (Direction d in CARDINALS) {
                    var ns = GetSite(my_site.X, my_site.Y, d);
                    if (ns.Owner != 0 && ns.Owner != mBotID) {
                        combat_move = true;
                        break;
                    }
                    else {
                        if (ns.Owner == 0) {
                            if (ns.Strength < weak_border_value) {
                                weak_border_value = ns.Strength;
                                weak_border_direction = d;
                            }
                        }
                    }
                }
                
                // not border or combat move (close to other players)
                if (combat_move) continue;
                if (weak_border_direction == Direction.Still) continue;
                
                // Direct move to weakest site
                var border_site = GetSite(my_site.X, my_site.Y, weak_border_direction);
                if (my_site.Strength > border_site.Strength) {
                    continue;
                }
                
                // Check if help from another site can expand territory
                foreach (Direction d in CARDINALS) {
                    var help_site = GetSite(my_site.X, my_site.Y, d);
                    if (help_site.Owner != mBotID) continue;
                    if (mMoved[help_site.X, help_site.Y]) continue;
                    if (Math.Min(255, help_site.Strength + my_site.Strength) > border_site.Strength) {
                        moves.Add(new Move(help_site.X, help_site.Y, Opposite(d)));
                        mMoved[help_site.X, help_site.Y] = true;
                        break;
                    }
                }
            }
        }
    }
    
    public Move GetMove(ushort x, ushort y) {
        Site my_site = mMap[x, y];

        Direction best_direction = GetBestDirectionToGo(x, y);

        if (best_direction != Direction.Still) {
            var best_site = GetSite(x, y, best_direction);
            if (best_site.Strength < my_site.Strength) {
                return new Move(x, y, best_direction);
            }
        }

        if (my_site.Strength < my_site.Production * 5) {
            return new Move(x, y, Direction.Still);
        }
        
        if (!IsBorder(x, y)) {
            var direction = FindNearestGoalDirection(x, y);
            var ns = GetSite(x, y, direction);
            if (my_site.Strength > 200 || ns.Strength + my_site.Strength < 255) {
                return new Move(x, y, direction);
            }
            return new Move(x, y, GetBestStrenghtDirection(x, y));
        }

        return new Move(x, y, Direction.Still);
    }

    private Direction GetBestStrenghtDirection(ushort x, ushort y) {
        int         current_strenght = mMap[x, y].Strength;
        int         best_strength = -1000;
        Direction   best_direction = Direction.Still;
        
        foreach (Direction d in CARDINALS) {
            var ns = GetSite(x, y, d);
            int combine = 255 - (current_strenght + ns.Strength);
            if (combine > best_strength) {
                best_strength = combine;
                best_direction = d;
            }
        }
        
        return best_direction;
    }
    
    public Direction GetBestDirectionToGo(ushort x, ushort y) {
        double      best_value = -1.0;
        Direction   best_direction = Direction.Still;

        foreach (Direction d in CARDINALS) {
            var ns = GetSite(x, y, d);
            if (ns.Owner == mBotID) continue;

            double site_value = 0;
            if (ns.Owner == 0 && ns.Strength > 0) {
                double site_strength = ns.Strength;
                double site_production = ns.Production;
                site_value = site_production / site_strength;
            }
            else {
                site_value = GetTotalDamage(ns.X, ns.Y);
            }

            if (site_value > best_value) {
                best_direction = d;
                best_value = site_value;
            }
        }

        return best_direction;
    }

    private double GetTotalDamage(ushort x, ushort y) {
        double total_damage = 0;
        foreach (Direction d in CARDINALS) {
            var site = GetSite(x, y, d);
            if (site.Owner != 0 && site.Owner != mBotID) 
                total_damage += site.Strength;
        }
        return total_damage;
    }

    private bool IsBorder(ushort x, ushort y) {
        foreach (Direction d in CARDINALS) {
            var site = GetSite(x, y, d);
            if (site.Owner != mBotID)
                return true;
        }
        return false;
    }

    private Direction FindNearestGoalDirection(ushort x, ushort y) {
        var direction = Direction.North;
        var max_dist = Math.Min(mMap.Width, mMap.Height) / 2;
        double current_goal_value = 0;

        foreach (Direction d in CARDINALS) {
            var goal_site = GetSite(x, y, d);
            var distance = 0;
            
            while (goal_site.Owner == mBotID && distance < max_dist + 1) {
                distance++;
                goal_site = GetSite(goal_site.X, goal_site.Y, d);
            }
            
            if (goal_site.Owner == mBotID) continue;
            
            var new_goal_value = GetGoalValue(goal_site, d);

            if (distance <= max_dist + 1 && new_goal_value >= current_goal_value) {
                direction = d;
                max_dist = distance;
                current_goal_value = new_goal_value;
            }
        }

        return direction;
    }
    
    private double GetGoalValue(Site goal_site, Direction d) {
        double value = 0;
        
        for (int i = 0; i < 4; i++) {
            if (goal_site.Owner == mBotID) continue;
            if (goal_site.Owner == 0 && goal_site.Strength > 0) {
                double site_strength = goal_site.Strength;
                double site_production = goal_site.Production;
                value += site_production / site_strength;
            }
            else {
                value += GetTotalDamage(goal_site.X, goal_site.Y);
            }
            if (d == Direction.North || d == Direction.South) {
                value += GetGoalDirectionValue(goal_site, Direction.East);
                value += GetGoalDirectionValue(goal_site, Direction.West);
            }
            if (d == Direction.East || d == Direction.West) {
                value += GetGoalDirectionValue(goal_site, Direction.North);
                value += GetGoalDirectionValue(goal_site, Direction.South);
            }
            goal_site = GetSite(goal_site.X, goal_site.Y, d);
        }
        
        return value;
    }

    private double GetGoalDirectionValue(Site goal_site, Direction d) {
        double value = 0;
        
        for (int i = 0; i < 4; i++) {
            if (goal_site.Owner == mBotID) continue;
            if (goal_site.Owner == 0 && goal_site.Strength > 0) {
                double site_strength = goal_site.Strength;
                double site_production = goal_site.Production;
                value += site_production / site_strength;
            }
            else {
                value += GetTotalDamage(goal_site.X, goal_site.Y);
            }
            goal_site = GetSite(goal_site.X, goal_site.Y, d);
        }
        
        return value;
    }

    public Site GetSite(ushort x, ushort y, Direction d) {
        if (d == Direction.West) {x = (ushort)((x == 0) ? mMap.Width - 1 : x - 1);}
        if (d == Direction.East) {x = (ushort)((x == mMap.Width - 1) ? 0 : x + 1);}
        if (d == Direction.North) {y = (ushort)((y == 0) ? mMap.Height - 1 : y - 1);}
        if (d == Direction.South) {y = (ushort)((y == mMap.Height - 1) ? 0 : y + 1);}
        return mMap[x, y];
    }

    private Direction Opposite(Direction direction) {
        if (direction == Direction.North) return Direction.South;
        if (direction == Direction.South) return Direction.North;
        if (direction == Direction.East) return Direction.West;
        if (direction == Direction.West) return Direction.East;
        return Direction.Still;
    }
    
}
