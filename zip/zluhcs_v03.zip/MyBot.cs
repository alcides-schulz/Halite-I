﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

public class MyBot
{
    public static void Main(string[] args) {
		    var engine = new ZEngine();
		    engine.Run();
    }
}
