using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Diagnostics;
using System.Threading;

//
// Zluhcs Engine for Halite AI Programming
//
public class ZEngine
{
    public const string BOT_NAME = "zluhcs";

    private ushort      mBotID;
    private Map         mMap;

	public Direction[]  CARDINALS = {Direction.North, Direction.East, Direction.South, Direction.West};
    
    private int         mRound = 0;
    private bool        mIsTunnelingActive = false;
    
    public Map          Map     {get {return mMap;}}
    public ushort       BotID   {get {return mBotID;}}
    
    private List<Site>  mMySites = new List<Site>();
    
    public void Run() {
        Console.SetIn(Console.In);
        Console.SetOut(Console.Out);
		
        mMap = Networking.getInit(out mBotID);
        
        InitSiteNeighbors();
        
        Networking.SendInit(BOT_NAME);
		
		while (true) {
            string line = Console.ReadLine();
            if (line == null) break;

			mMap.Update(line);
            
            SelectMySites();
            ExecuteNearBorderMove();
            CalculateMoves();
            
            Networking.SendMoves(mMySites);
            
            VerifyTunnelingEnd();
            
            mRound++;
        }
    }

    // For each site pre-poluate a list of its neighbors
    private void InitSiteNeighbors() {
        for (ushort y = 0; y < mMap.Height; y++) {
            for (ushort x = 0; x < mMap.Width; x++) {
                var site = mMap[x, y];
                foreach (Direction d in CARDINALS) {
                    var ns = GetNeighbor(site.X, site.Y, d);
                    site.Neighbors.Add(d, ns);
                }
            }
        }
    }

    // Return the neighbor site from a position in the map
    public Site GetNeighbor(ushort x, ushort y, Direction d) {
        if (d == Direction.West)  {x = (ushort)((x == 0) ? mMap.Width - 1 : x - 1);}
        if (d == Direction.East)  {x = (ushort)((x == mMap.Width - 1) ? 0 : x + 1);}
        if (d == Direction.North) {y = (ushort)((y == 0) ? mMap.Height - 1 : y - 1);}
        if (d == Direction.South) {y = (ushort)((y == mMap.Height - 1) ? 0 : y + 1);}
        return mMap[x, y];
    }
    
    // Create a list with my sites.
    private void SelectMySites() {
        mMySites.Clear();
        for (ushort y = 0; y < mMap.Height; y++) {
            for (ushort x = 0; x < mMap.Width; x++) {
                var site = mMap[x, y];
                site.AddedStrenght = 0;
                if (site.Owner != mBotID) continue;
                site.ClearMove();
                mMySites.Add(site);
            }
        }
    }
    
    // Calculate moves near border, exclude combat moves.
    public void ExecuteNearBorderMove() {
        foreach (var my_site in mMySites) {
            if (my_site.HasMoved) continue;
            if (!IsStrongToMove(my_site)) continue;
            if (IsInTunnelingMap(my_site)) continue;
            
            // See if there's a direction to near border
            var best_border_direction = GetBestBorderDirection(my_site);
            if (best_border_direction == Direction.Still) continue;

            var border_site = my_site.Neighbors[best_border_direction];
            if (my_site.Strength > border_site.Strength) continue;
            
            foreach (Direction d in CARDINALS) {
                var help_site = my_site.Neighbors[d];
                if (help_site.Owner != mBotID) continue;
                if (help_site.HasMoved) continue;
                if (CanWinTerritory(help_site)) continue;
                if (Math.Min(255, help_site.Strength + my_site.Strength) > border_site.Strength) {
                    help_site.SetMove(Opposite(d));
                    break;
                }
            }
        }
    }

    // Return a move to near border unless this is site that can enter combat
    private Direction GetBestBorderDirection(Site my_site) {
        Direction best_border_direction = Direction.Still;
        double best_border_value = 0;
        foreach (Direction d in my_site.Neighbors.Keys) {
            var ns = my_site.Neighbors[d];
            if (IsCombatSite(ns)) return Direction.Still;
            if (ns.Owner == 0 && ns.Strength != 0) {
                double value = (double)ns.Production / (double)ns.Strength;
                if (value > best_border_value) {
                    best_border_value = value;
                    best_border_direction = d;
                }
            }
        }
        return best_border_direction;
    }
    
    // Calculate moves for all pieces.
    public void CalculateMoves() {
        foreach (var my_site in mMySites) {
            if (my_site.HasMoved) continue;

            Direction best_direction = GetBestDirectionToGo(my_site);
            if (best_direction != Direction.Still) {
                var target_site = my_site.Neighbors[best_direction];

                if (!mIsTunnelingActive) VerifyTunnelingStart(my_site, target_site);
                
                // if (target_site.Owner == 0 && target_site.Strength > my_site.Strength) {
                    // var after_site = target_site.Neighbors[best_direction];
                    // if (IsEnemySite(after_site)) {
                        // my_site.SetMove(Opposite(best_direction));
                        // continue;
                    // }
                // }
                
                if (target_site.Strength < my_site.Strength || (my_site.Strength > 0 && target_site.Strength == 255)) {
                    my_site.SetMove(best_direction);
                    continue;
                }
               
            }

            if (!IsStrongToMove(my_site)) {
                my_site.SetMove(Direction.Still);
                continue;
            }

            if (mIsTunnelingActive) {
                var tunnel_direction = GetTunnelDirection(my_site);
                if (tunnel_direction != Direction.Still) {
                    my_site.SetMove(tunnel_direction);
                    continue;
                }
            }
            
            if (!IsBorder(my_site)) {
                var direction = FindNearestGoalDirection(my_site);
                var ns = my_site.Neighbors[direction];
                if (my_site.Strength > 200 || ns.Strength + my_site.Strength < 255) {
                    my_site.SetMove(direction);
                    continue;
                }
                my_site.SetMove(GetBestStrenghtDirection(my_site));
                my_site.SetMove(direction);
                continue;
            }

            my_site.SetMove(Direction.Still);
        }
    }
    
    private Direction GetTunnelDirection(Site site) {
        var tunnel_direction = Direction.Still;
        var from_value = GetTunnelMapValue(site);
        foreach (Direction d in site.Neighbors.Keys) {
            var ns = site.Neighbors[d];
            var to_value = GetTunnelMapValue(ns);
            if (to_value != 0 && to_value > from_value) tunnel_direction = d;
        }
        return tunnel_direction;
    }
    
    private void VerifyTunnelingStart(Site my_site, Site target_site) {
        foreach (Direction d in target_site.Neighbors.Keys) {
            var ns = target_site.Neighbors[d];
            if (IsEnemySite(ns)) {
                CalculateTunnelMap(my_site, target_site, ns);
                return;
            }
        }
    }
    
    public int GetTunnelMapValue(Site site) {
        return site.TunnelValue;
    }
    
    private bool CanEnterCombat(Site site) {
        foreach (var ns1 in site.Neighbors.Values) {
            foreach (var ns2 in ns1.Neighbors.Values) {
                if (IsEnemySite(ns2)) return true;
            }
        }
        return false;
    }

    private Direction GetBestStrenghtDirection(Site site) {
        int         current_strenght = site.Strength;
        int         best_strength = -1000;
        Direction   best_direction = Direction.Still;
        
        foreach (Direction d in site.Neighbors.Keys) {
            var ns = site.Neighbors[d];
            int combine = 255 - (current_strenght + ns.Strength);
            if (combine > best_strength) {
                best_strength = combine;
                best_direction = d;
            }
        }
        
        return best_direction;
    }
    
    public Direction GetBestDirectionToGo(Site site) {
        double      best_value = -1.0;
        Direction   best_direction = Direction.Still;
        double      my_strenght = site.Strength;

        foreach (Direction d in site.Neighbors.Keys) {
            var ns = site.Neighbors[d];
            if (ns.Owner == mBotID) continue;
            double site_value = 0;
            if (ns.Owner == 0) {
                if (ns.Strength != 0)
                    site_value = (double)ns.Production / (double)ns.Strength;
                else
                    site_value = (double)ns.Production;
            }
            //site_value += GetPotentialDamage(site, d, ns);
            site_value += my_strenght * EnemyCount(ns);

            if (site_value > best_value) {
                best_direction = d;
                best_value = site_value;
            }
        }
        
        // if (best_value > 0 && GetPotentialDamage(site, best_direction, site.Neighbors[best_direction]) > 0) {
            // string line = "";
            // line += site.CsvValues() + ",";
            // line += best_direction + ",";
            // line += site.Neighbors[best_direction].CsvValues() + ",";
            // line += GetPotentialDamage(site, best_direction, site.Neighbors[best_direction]) + ",";
            // line += best_value + ",";
            // line += Environment.NewLine;
            // File.AppendAllText("debug/damage-" + mRound + ".csv", line);
        // }
        

        return best_direction;
    }
    
    private int GetPotentialDamage(Site my_site, Direction move_direction, Site to_site) {
        int my_strenght = my_site.Strength;
        int damage_received = 0;
        int damage_applied = 0;
        
        // string f = "debug/damage-" + mRound + ".csv";
        foreach (Direction d in to_site.Neighbors.Keys) {
            if (d == Opposite(move_direction)) continue;
            Site ns = to_site.Neighbors[d];
            if (!IsEnemySite(ns)) continue;
            damage_received += Math.Min(my_strenght, ns.Strength);
            damage_applied += Math.Min(my_strenght, ns.Strength);
            // string line = "";
            // line += my_site.CsvValues() + ",";
            // line += move_direction + ",";
            // line += to_site.CsvValues() + ",";
            // line += d + ",";
            // line += ns.CsvValues() + ",";
            // line += "DR=" + damage_received + ",";
            // line += "DA=" + damage_applied + ",";
            // line += Environment.NewLine;
            // File.AppendAllText(f, line);
        }
        my_strenght -= damage_received;
        if (to_site.Owner == 0) my_strenght -= to_site.Strength;
        if (my_strenght <= 0) return damage_applied;
        return damage_applied + GetAdditionalDamage(to_site, move_direction, my_strenght);
    }    
    
    private int GetAdditionalDamage(Site to_site, Direction move_direction, int my_strenght) {
        int additional_damage = 0;
        foreach (Direction d in to_site.Neighbors.Keys) {
            if (d == Opposite(move_direction)) continue;
            Site ns1 = to_site.Neighbors[d];
            var current_strenght = my_strenght;
            if (ns1.Owner == 0) current_strenght = Math.Min(0, current_strenght - ns1.Strength);
            if (current_strenght == 0) continue;
            int damage = 0;
            foreach (Direction d1 in ns1.Neighbors.Keys) {
                if (d1 == Opposite(d)) continue;
                if (d1 == Opposite(move_direction)) continue;
                var ns2 = ns1.Neighbors[d1];
                if (!IsEnemySite(ns2)) continue;
                damage += Math.Min(current_strenght, ns2.Strength);
            }
            if (damage > additional_damage) additional_damage = damage;
        }
        return additional_damage;
    }
    
    private int EnemyCount(Site site) {
        // int     count = 0;
        // foreach (Site ns in site.Neighbors.Values) {
            // if (IsEnemySite(ns)) count += 1;
        // }
        // return count;
        return site.Neighbors.Values.Where(s => IsEnemySite(s)).Count();
    }

    public bool IsBorder(Site site) {
        // foreach (Site ns in site.Neighbors.Values) {
            // if (ns.Owner == 0) return true;
        // }
        // return false;
        return site.Neighbors.Values.Where(s => s.Owner == 0).Count() != 0;
    }

    private bool CanWinTerritory(Site site) {
        foreach (Site ns in site.Neighbors.Values) {
            if (ns.Owner == 0 && ns.Strength < site.Strength) return true;
        }
        return false;
    }
    
    public bool IsCombatSite(Site site) {
        // foreach (Site ns in site.Neighbors.Values) {
            // if (ns.Owner != 0 && ns.Owner != mBotID) return true;
        // }
        // return false;
        return site.Neighbors.Values.Where(s => IsEnemySite(s)).Count() != 0;
    }
    
    private Direction FindNearestGoalDirection(Site site) {
        var direction = Direction.North;
        var max_dist = Math.Min(mMap.Width, mMap.Height) / 2;
        double current_goal_value = 0;
        var best_dist = 999999;

        foreach (Direction d in site.Neighbors.Keys) {
            var goal_site = site.Neighbors[d];
            var distance = 0;
            
            while (goal_site.Owner == mBotID && distance < max_dist) {
                distance++;
                goal_site = goal_site.Neighbors[d];
            }
            
            if (goal_site.Owner == mBotID) continue;
            
            var new_goal_value = GetGoalValue(goal_site, d);

            if (distance < best_dist || (distance <= best_dist + 2 && new_goal_value >= current_goal_value)) {
                direction = d;
                best_dist = distance;
                current_goal_value = new_goal_value;
            }
        }

        return direction;
    }

    private double GetGoalValue(Site goal_site, Direction d) {
        double value = 0;
        
        for (int i = 0; i < 4; i++) {
            value += GetSiteValue(goal_site);
            if (d == Direction.North || d == Direction.South) {
                value += GetGoalDirectionValue(goal_site, Direction.East);
                value += GetGoalDirectionValue(goal_site, Direction.West);
            }
            if (d == Direction.East || d == Direction.West) {
                value += GetGoalDirectionValue(goal_site, Direction.North);
                value += GetGoalDirectionValue(goal_site, Direction.South);
            }
            goal_site = goal_site.Neighbors[d];
        }
        
        return value;
    }

    private double GetGoalDirectionValue(Site goal_site, Direction d) {
        double value = 0;
        
        for (int i = 0; i < 4; i++) {
            goal_site = goal_site.Neighbors[d];
            value += GetSiteValue(goal_site);
        }
        
        return value;
    }
    
    private double GetSiteValue(Site site) {
        if (site.Owner == mBotID) return 0;
        
        //if (site.Owner == 0 && site.Strength != 0) 
        if (site.Strength != 0) 
            return (double)site.Production / (double)site.Strength;

        return (double)site.Production;
    }

    public bool IsEnemySite(Site site) {
        return site.Owner != 0 && site.Owner != mBotID;
    }
    
    public bool IsStrongToMove(Site site) {
        return site.Strength >= site.Production * 5;
    }
    
    public bool IsInTunnelingMap(Site site) {
        return site.TunnelValue != 0;
    }
    
    public Direction Opposite(Direction direction) {
        if (direction == Direction.North) return Direction.South;
        if (direction == Direction.South) return Direction.North;
        if (direction == Direction.East) return Direction.West;
        if (direction == Direction.West) return Direction.East;
        return Direction.Still;
    }

    private void CalculateTunnelMap(Site my_site, Site connect, Site enemy) {
        if (mIsTunnelingActive) return;
        
        for (ushort y = 0; y < mMap.Height; y++) {
		    for (ushort x = 0; x < mMap.Width; x++) {
				mMap[x, y].TunnelValue = 0;
			}
		}
        
		var queue = new Queue<Site>();
		queue.Enqueue(connect);
        connect.TunnelValue = 1;
		
		while(queue.Count != 0) {
			var current = queue.Dequeue();
			foreach (Site ns in current.Neighbors.Values) {
                if (ns.TunnelValue != 0) continue;
                if (ns.Owner == mBotID || ns.Owner == enemy.Owner) {
                    ns.TunnelValue = current.TunnelValue + 1;
                    queue.Enqueue(ns);
                }
			}
		}

        var max = Math.Min(mMap.Width, mMap.Height) / 3;

        for (ushort y = 0; y < mMap.Height; y++) {
		    for (ushort x = 0; x < mMap.Width; x++) {
                var site = mMap[x, y];
                if (site.Owner == mBotID) site.TunnelValue *= -1;
                if (site.Owner == mBotID && site.TunnelValue < -max) site.TunnelValue = 0;
                if (site.Owner == enemy.Owner && site.TunnelValue > max) site.TunnelValue = 0;
			}
		}
        
        mIsTunnelingActive = true;
        
        // string f = "attack-" + mRound + ".csv";
        // for (ushort y = 0; y < mMap.Height; y++) {
            // string line = "";
		    // for (ushort x = 0; x < mMap.Width; x++) {
				// if (line != "") line += ",";
                // line += mTunnelMap[x, y];
			// }
            // File.AppendAllText(f, line + Environment.NewLine);
		// }
	}    

    private void VerifyTunnelingEnd() {
        if (mIsTunnelingActive == false) return;
        
        int enemy_territory = 0;
        int my_count = 0;
        
        for (ushort y = 0; y < mMap.Height; y++) {
		    for (ushort x = 0; x < mMap.Width; x++) {
                var site = mMap[x, y];
                if (site.TunnelValue > 0) {
                    enemy_territory++;
                    if (site.Owner == mBotID) my_count++;
                }
			}
		}

        if (my_count >= enemy_territory - 10) mIsTunnelingActive = false;
    }    
    
    private void PrintState(string message, Site site) {
        string filename = "debug/state-" + mRound + ".csv";
        for (ushort y = 0; y < mMap.Height; y++) {
            string line = "";
		    for (ushort x = 0; x < mMap.Width; x++) {
                if (line != "") line += ",";
                line += mMap[x, y].StateString();
            }
            File.AppendAllText(filename, line + Environment.NewLine);
        }
        File.AppendAllText(filename, message + ",Site=" + site.StateString() + Environment.NewLine);
        
    }
}
