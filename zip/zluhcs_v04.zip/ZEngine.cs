using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Diagnostics;
using System.Threading;

//
// Zluhcs Engine for Halite AI Programming - version 4
//
public class ZEngine
{
    public const string BOT_NAME = "zluhcs";

    private ushort      mBotID;
    private Map         mMap;

	private Direction[] CARDINALS = {Direction.North, Direction.East, Direction.South, Direction.West};
    
    private bool[,]     mMoved;

	public class ZInput {
		private string mLine = "";
		
		public bool HasLine() {
			return mLine != "";
		}
		
		public void ReadLine() {
			while(true) {
				mLine = Console.ReadLine();
                if (mLine == null)
                    mLine = "";
			}
		}
		
		public string GetLine() {
			string temp = mLine;
			mLine = "";
			return temp;
		}
	}
	
    public ZEngine() {

    }

    public void Run() {
        Console.SetIn(Console.In);
        Console.SetOut(Console.Out);
		
        mMap = Networking.getInit(out mBotID);
        
        mMoved = new bool[mMap.Width, mMap.Height];
        
        Networking.SendInit(BOT_NAME);
		
        int round = 0;
        
		while (true) {
            string line = Console.ReadLine();
            if (line == null) break;

            //Networking.getFrame(ref mMap);
			mMap.Update(line);
            
            round++;

            var moves = new List<Move>();

            ExecuteNearBorderMove(round, moves);
            
            for (ushort y = 0; y < mMap.Height; y++) {
                for (ushort x = 0; x < mMap.Width; x++) {
                    if (mMap[x, y].Owner == mBotID && !mMoved[x, y]) {
                        moves.Add(GetMove(mMap, x, y));
                    }
                }
            }

            Networking.SendMoves(moves);
        }
    }
    
    // private void CalculateBorderMoves(int round, List<Move> moves) {
        // List<Site> my_site = new List<Site>();
        
        // for (ushort y = 0; y < mMap.Height; y++) {
            // for (ushort x = 0; x < mMap.Width; x++) {
                // Site s = mMap[x, y];
                // if (s.Owner != mBotID) continue;
                // if (!IsBorder(x, y)) continue;
                // my_site.Add(s);
            // }
        // }
        
        
    // }
    
    // moves near border, exclude opponents
    public void ExecuteNearBorderMove(int round, List<Move> moves) {
        if (round <= 100) {
            for (ushort y = 0; y < mMap.Height; y++) {
                for (ushort x = 0; x < mMap.Width; x++) {
                    mMoved[x, y] = false;
                }
            }
        }
        
        if (round >= 100) return;
        
        for (ushort y = 0; y < mMap.Height; y++) {
            for (ushort x = 0; x < mMap.Width; x++) {
                
                if (mMoved[x, y]) continue;
                
                Location location = new Location();
                location.X = x;
                location.Y = y;
                var my_site = mMap[x, y];
                
                if (my_site.Owner != mBotID) continue;
                if (my_site.Strength < my_site.Production * 5) continue;
                
                bool combat_move = false;
                Direction weak_border_direction = Direction.Still;
                int weak_border_value = 1000;
                
                foreach (Direction d in CARDINALS) {
                    var ns = GetSite(mMap, location, d);
                    if (ns.Owner != 0 && ns.Owner != mBotID) {
                        combat_move = true;
                        break;
                    }
                    else {
                        if (ns.Owner == 0) {
                            if (ns.Strength < weak_border_value) {
                                weak_border_value = ns.Strength;
                                weak_border_direction = d;
                            }
                        }
                    }
                }
                
                // not border or combat move (close to other players)
                if (combat_move) continue;
                if (weak_border_direction == Direction.Still) continue;
                
                // Direct move to weakest site
                var border_site = GetSite(mMap, location, weak_border_direction);
                if (my_site.Strength > border_site.Strength) {
                    // var move = new Move();
                    // move.Location = location;
                    // move.Direction = weak_border_direction;
                    // moves.Add(move);
                    // mMoved[x, y] = true;
                    continue;
                }
                
                // Check if help from another site can expand territory
                foreach (Direction d in CARDINALS) {
                    var nl = GetLocation(mMap, location, d);
                    var ns = GetSite(mMap, location, d);
                    if (ns.Owner != mBotID) continue;
                    if (mMoved[nl.X, nl.Y]) continue;
                    if (Math.Min(255, ns.Strength + my_site.Strength) > border_site.Strength) {
                        Move move = new Move();
                        move.Location = nl;
                        move.Direction = Opposite(d);
                        moves.Add(move);
                        mMoved[nl.X, nl.Y] = true;
                        break;
                    }
                }
            }
        }
    }
    
    private Direction Opposite(Direction direction) {
        if (direction == Direction.North) return Direction.South;
        if (direction == Direction.South) return Direction.North;
        if (direction == Direction.East) return Direction.West;
        if (direction == Direction.West) return Direction.East;
        return Direction.Still;
    }
    
    public Move GetMove(Map map, ushort x, ushort y) {
        Move move = new Move();
        
        move.Location.X = x;
        move.Location.Y = y;

        Site my_site = map[x, y];

        Direction best_direction = GetBestDirectionToGo(move.Location);

        if (best_direction != Direction.Still) {
            var best_site = GetSite(mMap, move.Location, best_direction);
            if (best_site.Strength < my_site.Strength) {
                move.Direction = best_direction;
                return move;
            }
        }

        if (my_site.Strength < my_site.Production * 5) {
            move.Direction = Direction.Still;
            return move;
        }
        
        if (!IsBorder(move.Location)) {
            var direction = FindNearestGoalDirection(move.Location);
            var ns = GetSite(mMap, move.Location, direction);
            //if (my_site.Strength > 150 || ns.Strength + my_site.Strength < 255) {
            if (my_site.Strength > 200 || ns.Strength + my_site.Strength < 255) {
                move.Direction = direction;
                return move;
            }
            move.Direction = GetBestStrenghtDirection(move.Location);
            return move;
        }

        move.Direction = Direction.Still;
        return move;
    }

    private Direction GetBestStrenghtDirection(Location location) {
        int         current_strenght = mMap[location.X, location.Y].Strength;
        int         best_strength = -1000;
        Direction   best_direction = Direction.Still;
        
        foreach (Direction d in CARDINALS) {
            var ns = GetSite(mMap, location, d);
            int combine = 255 - (current_strenght + ns.Strength);
            if (combine > best_strength) {
                best_strength = combine;
                best_direction = d;
            }
        }
        
        return best_direction;
    }
    
    public Direction GetBestDirectionToGo(Location location) {
        double      best_value = -1.0;
        Direction   best_direction = Direction.Still;

        foreach (Direction d in CARDINALS) {
            var nl = GetLocation(mMap, location, d);
            var ns = mMap[nl.X, nl.Y];
            
            if (ns.Owner == mBotID) continue;

            double site_value = 0;
            if (ns.Owner == 0 && ns.Strength > 0) {
                double site_strength = ns.Strength;
                double site_production = ns.Production;
                site_value = site_production / site_strength;
            }
            else {
                site_value = GetTotalDamage(nl);
            }

            if (site_value > best_value) {
                best_direction = d;
                best_value = site_value;
            }
        }

        return best_direction;
    }

    private double GetTotalDamage(Location location) {
        double total_damage = 0;
        foreach (Direction d in CARDINALS) {
            var site = GetSite(mMap, location, d);
            if (site.Owner != 0 && site.Owner != mBotID) 
                total_damage += site.Strength;
        }
        return total_damage;
    }

    private bool IsBorder(Location location) {
        foreach (Direction d in CARDINALS) {
            var site = GetSite(mMap, location, d);
            if (site.Owner != mBotID)
                return true;
        }
        return false;
    }

    private bool IsBorder(ushort x, ushort y) {
        Location location = new Location();
        location.X = x;
        location.Y = y;
        return IsBorder(location);
    }
    
    private Direction FindNearestGoalDirection(Location location) {
        var direction = Direction.North;
        var max_dist = Math.Min(mMap.Width, mMap.Height) / 2;

        foreach (Direction d in CARDINALS) {
            var l = GetLocation(mMap, location, d);
            var ns = mMap[l.X, l.Y];
            var distance = 0;
            var current = l;

            while (ns.Owner == mBotID && distance < max_dist) {
                distance++;
                current = GetLocation(mMap, current, d);
                ns = mMap[current.X, current.Y];
            }

            if (distance < max_dist) {
                direction = d;
                max_dist = distance;
            }
        }

        return direction;
    }

    public Location GetLocation(Map map, Location loc, Direction d) {
        ushort     x = loc.X;
        ushort     y = loc.Y;
        
        if (d == Direction.West) {x = (ushort)((x == 0) ? map.Width - 1 : x - 1);}
        if (d == Direction.East) {x = (ushort)((x == map.Width - 1) ? 0 : x + 1);}
        if (d == Direction.North) {y = (ushort)((y == 0) ? map.Height - 1 : y - 1);}
        if (d == Direction.South) {y = (ushort)((y == map.Height - 1) ? 0 : y + 1);}
        
        var l = new Location();
        l.X = x;
        l.Y = y;
        
        return l;
    }

    public Site GetSite(Map map, Location loc, Direction d) {
        ushort     x = loc.X;
        ushort     y = loc.Y;
        
        if (d == Direction.West) {x = (ushort)((x == 0) ? map.Width - 1 : x - 1);}
        if (d == Direction.East) {x = (ushort)((x == map.Width - 1) ? 0 : x + 1);}
        if (d == Direction.North) {y = (ushort)((y == 0) ? map.Height - 1 : y - 1);}
        if (d == Direction.South) {y = (ushort)((y == map.Height - 1) ? 0 : y + 1);}
        
        return mMap[x, y];
    }
    
}
